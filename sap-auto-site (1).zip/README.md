# SAP Auto Site (Static, Free-Hosted)

A zero-cost static website that **auto-fetches the latest SAP technology news and free SAP courses**, then **rebuilds and redeploys daily** via GitHub Actions to GitHub Pages.

> Footer credits: **Designed by Abhishek Goyal** — Email: **abhishek.goyal@example.com** — LinkedIn: **https://www.linkedin.com/in/abhishekgoyal**  
> Share your real email/LinkedIn if you want me to update these now.

## What this does
- Scrapes/reads **SAP news** from public feeds (SAP Newsroom, SAP Blogs).
- Scrapes **free SAP courses** (openSAP, plus free SAP courses on Coursera/edX where found).
- Generates a **clean, responsive static site** (HTML/CSS) with sections for:
  - Latest SAP Tech Highlights
  - Free SAP Courses (by domain/topic)
  - Search + Filters
- Deploys daily using **GitHub Actions** to **GitHub Pages** (free).

## One-time setup (you can skip and ask me to do these edits)
1. Create a new GitHub repo and upload the contents of this folder (or click **Use this template** if provided).
2. In GitHub, go to **Settings → Pages → Build and deployment**, set **Source: GitHub Actions**.
3. The included workflow will automatically publish to Pages after each daily build or on every push.

That’s it. No servers, no costs.

## Local dev (optional)
```bash
npm install
npm run build
# Output in ./dist
```

## How it works
- `scripts/fetch.js` pulls from RSS/pages, normalizes results into JSON under `data/`.
- `scripts/build.js` renders to static HTML using lightweight templates from `templates/` and styles from `public/`.
- GitHub Actions (`.github/workflows/deploy.yml`) runs daily and on pushes; it deploys the `dist/` folder to Pages.

## Customizing the footer
Edit `site.config.json`:
```json
{
  "ownerName": "Abhishek Goyal",
  "ownerEmail": "abhishek.goyal@example.com",
  "ownerLinkedIn": "https://www.linkedin.com/in/abhishekgoyal"
}
```
I can update these for you if you provide your real contacts.

## Data sources (editable in `site.config.json`)
- SAP Newsroom RSS: https://news.sap.com/feed/
- SAP Blogs (Technology topics): https://blogs.sap.com/tags/ (various tag feeds)
- openSAP courses: https://open.sap.com/
- Coursera/edX search queries for "SAP" + "free" (best-effort; filters to free/accessible).

> Note: Some sources may change structure/CORS. The build uses GitHub Actions (server-side), so CORS is not an issue. If a selector changes, I can tweak the scraper quickly.

## License
MIT
