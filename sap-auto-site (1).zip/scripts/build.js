import fs from 'fs';
import path from 'path';

const root = process.cwd();
const dist = path.join(root, 'dist');
const dataDir = path.join(root, 'data');
const pub = path.join(root, 'public');

if (!fs.existsSync(dist)) fs.mkdirSync(dist, { recursive: true });

const config = JSON.parse(fs.readFileSync(path.join(root, 'site.config.json'), 'utf8'));
const news = JSON.parse(fs.readFileSync(path.join(dataDir, 'news.json'), 'utf8'));
const courses = JSON.parse(fs.readFileSync(path.join(dataDir, 'courses.json'), 'utf8'));
const template = fs.readFileSync(path.join(root, 'templates', 'index.html'), 'utf8');

// Copy public assets
function copyDir(src, dest){
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  for (const e of fs.readdirSync(src)){
    const s = path.join(src, e);
    const d = path.join(dest, e);
    const st = fs.statSync(s);
    if (st.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}
copyDir(pub, path.join(dist));

function escapeHtml(s){ return (s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function renderNewsCard(n){
  return `
  <article class="card">
    <h3><a href="${escapeHtml(n.link)}" target="_blank" rel="noopener">${escapeHtml(n.title)}</a></h3>
    <p class="meta">${n.date ? new Date(n.date).toLocaleString() : ''}</p>
  </article>`;
}

function renderCourseCard(c){
  return `
  <article class="card course">
    <div class="label">${escapeHtml(c.provider)}</div>
    <h3><a href="${escapeHtml(c.link)}" target="_blank" rel="noopener">${escapeHtml(c.title)}</a></h3>
    <p class="meta">${escapeHtml(c.domain)} • Free</p>
  </article>`;
}

const newsHtml = news.map(renderNewsCard).join('\n');
const coursesHtml = courses.map(renderCourseCard).join('\n');

const out = template
  .replace(/%SITE_TITLE%/g, escapeHtml(config.siteTitle))
  .replace(/%TAGLINE%/g, escapeHtml(config.tagline))
  .replace(/%NEWS_CARDS%/g, newsHtml)
  .replace(/%COURSE_CARDS%/g, coursesHtml)
  .replace(/%OWNER_NAME%/g, escapeHtml(config.ownerName))
  .replace(/%OWNER_EMAIL%/g, escapeHtml(config.ownerEmail))
  .replace(/%OWNER_LINKEDIN%/g, escapeHtml(config.ownerLinkedIn));

fs.writeFileSync(path.join(dist, 'index.html'), out, 'utf8');
console.log('Built site to dist/index.html');
