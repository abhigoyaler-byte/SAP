import fs from 'fs';
import path from 'path';
import Parser from 'rss-parser';
import fetch from 'node-fetch';
import * as cheerio from 'cheerio';
import { DateTime } from 'luxon';

const root = process.cwd();
const dataDir = path.join(root, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const config = JSON.parse(fs.readFileSync(path.join(root, 'site.config.json'), 'utf8'));
const parser = new Parser({
  headers: { 'User-Agent': 'sap-auto-site/1.0 (+github pages)' }
});

function normalizeText(t){ return (t||'').replace(/\s+/g,' ').trim(); }

async function getRssFeed(url){
  try {
    const feed = await parser.parseURL(url);
    return (feed.items || []).map(it => ({
      title: normalizeText(it.title),
      link: it.link,
      date: it.isoDate || it.pubDate || null,
      source: url
    }));
  } catch (e){
    console.error('RSS error', url, e.message);
    return [];
  }
}

// openSAP: basic scrape of the main page for course cards (free by default)
async function getOpenSAPCourses(){
  try{
    const res = await fetch(config.sources.openSAP, { headers: { 'User-Agent': 'sap-auto-site/1.0' }});
    const html = await res.text();
    const $ = cheerio.load(html);
    const items = [];
    // Heuristic selectors - robust-ish
    $('a[data-gtm="course-card"], a.card').each((i, el)=>{
      const $el = $(el);
      const title = normalizeText($el.find('[class*="title"], h3, h2').first().text()) || normalizeText($el.attr('title'));
      const href = $el.attr('href');
      if (title && href){
        items.push({
          title,
          link: href.startsWith('http') ? href : `https://open.sap.com${href}`,
          provider: 'openSAP',
          free: true,
          domain: inferDomain(title)
        });
      }
    });
    return items;
  }catch(e){
    console.error('openSAP scrape failed', e.message);
    return [];
  }
}

// Coursera search (free filter applied in URL). We avoid API; scrape basic cards.
async function getCourseraFree(){
  try{
    const res = await fetch(config.sources.courseraSearch, { headers: { 'User-Agent': 'sap-auto-site/1.0' }});
    const html = await res.text();
    const $ = cheerio.load(html);
    const items = [];
    $('a[href*="/learn/"], a.css-1j8o68f').each((i, a)=>{
      const $a = $(a);
      const href = $a.attr('href');
      const title = normalizeText($a.text());
      if (title && href){
        items.push({
          title,
          link: href.startsWith('http') ? href : `https://www.coursera.org${href}`,
          provider: 'Coursera',
          free: true,
          domain: inferDomain(title)
        });
      }
    });
    return dedupeByLink(items).slice(0, 40);
  }catch(e){
    console.error('Coursera scrape failed', e.message);
    return [];
  }
}

// edX search
async function getEdxFree(){
  try{
    const res = await fetch(config.sources.edxSearch, { headers: { 'User-Agent': 'sap-auto-site/1.0' }});
    const html = await res.text();
    const $ = cheerio.load(html);
    const items = [];
    $('a[href*="/course/"]').each((i, a)=>{
      const $a = $(a);
      const href = $a.attr('href');
      const title = normalizeText($a.text());
      if (title && href){
        items.push({
          title,
          link: href.startsWith('http') ? href : `https://www.edx.org${href}`,
          provider: 'edX',
          free: true,
          domain: inferDomain(title)
        });
      }
    });
    return dedupeByLink(items).slice(0, 40);
  }catch(e){
    console.error('edX scrape failed', e.message);
    return [];
  }
}

function inferDomain(title){
  const t = title.toLowerCase();
  if (t.includes('s/4') || t.includes('s4') || t.includes('s4hana')) return 'S/4HANA';
  if (t.includes('abap')) return 'ABAP';
  if (t.includes('hana') && !t.includes('s/4')) return 'SAP HANA';
  if (t.includes('btp') || t.includes('cloud platform')) return 'SAP BTP';
  if (t.includes('analytics') || t.includes('sac')) return 'Analytics (SAC)';
  if (t.includes('fiori')) return 'Fiori/UI5';
  if (t.includes('ariba')) return 'Ariba';
  if (t.includes('successfactors')) return 'SuccessFactors';
  if (t.includes('ibp')) return 'IBP';
  return 'General';
}

function dedupeByLink(arr){
  const seen = new Set();
  const out = [];
  for (const it of arr){
    const key = it.link.split('?')[0];
    if (!seen.has(key)){
      seen.add(key); out.push(it);
    }
  }
  return out;
}

async function run(){
  const newsFeedUrls = config.sources.newsFeeds || [];
  let news = [];
  for (const f of newsFeedUrls){
    const items = await getRssFeed(f);
    news = news.concat(items);
  }
  // Sort by recency and keep top 50
  news = news
    .filter(n => n.title && n.link)
    .map(n => ({...n, ts: n.date ? DateTime.fromISO(n.date, {zone:'utc'}).toMillis() : 0}))
    .sort((a,b)=> b.ts - a.ts)
    .slice(0, 50);

  const openSap = await getOpenSAPCourses();
  const coursera = await getCourseraFree();
  const edx = await getEdxFree();

  const courses = dedupeByLink([...openSap, ...coursera, ...edx]).slice(0, 100);

  fs.writeFileSync(path.join(dataDir, 'news.json'), JSON.stringify(news, null, 2));
  fs.writeFileSync(path.join(dataDir, 'courses.json'), JSON.stringify(courses, null, 2));
  console.log(`Saved ${news.length} news items and ${courses.length} courses.`);
}

run();
